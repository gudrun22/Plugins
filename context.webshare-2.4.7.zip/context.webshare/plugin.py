# -*- coding: utf8 -*-


import os
import xbmcaddon
import xbmc
import routing
import webshare
import xbmcgui
import xbmcplugin


plugin = routing.Plugin()


class Router:

    def __init__(self):

        self._parse_argv()
        plugin.run()

    def _parse_argv(self):
        args = sys.argv[2][1:]
        self.params = {"handle": plugin.handle}


@plugin.route('/vip')
def vip():
    webshare.get_vip()


@plugin.route('/history')
def history():
    webshare.history()


@plugin.route('/session')
def session():
    webshare.session_history()


@plugin.route('/donate')
def donate():
    xbmc.executebuiltin('ShowPicture('+ 'http://saros.wz.cz/repo/PayPal_my_qrcode.jpg'+')')


@plugin.route('/addlib')
def addlib():
    import addlib


@plugin.route('/play/<ident>')
def play(ident):
    url = webshare.get_stream_url(ident)
    listitem = xbmcgui.ListItem(path=url)
    listitem.setProperty('IsPlayable', 'true')
    xbmcplugin.setResolvedUrl(plugin.handle, True, listitem)


if (__name__ == "__main__"):
    Router()
