# -*- coding: utf-8 -*-

import webshare
webshare.run()